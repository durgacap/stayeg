---
Task ID: 2-a
Agent: full-stack-developer
Task: Update all API routes to use lazy Supabase client with demo data fallback

Work Log:
- Read all 13 API route files and 2 dependency files (supabase.ts, demo-data.ts)
- Updated 12 API route files to use `getSupabase()` instead of deprecated `supabase` import
- For each GET handler: added `const supabase = getSupabase(); if (!supabase) return demoData;` pattern
- For each POST/PUT/PATCH handler: added `if (!supabase) return 503` pattern
- Fixed pre-existing syntax error in supabase.ts line 51 (extra closing paren in proxy no-op chain)
- Skipped setup-db/route.ts (uses pg library directly, not supabase)

Files updated:
1. src/app/api/route.ts — GET returns `{ message: 'Hello, world!', supabase: 'demo-mode' }`
2. src/app/api/pgs/route.ts — GET returns formatted demoPGs, POST/PUT return 503
3. src/app/api/pgs/[id]/route.ts — GET finds demo PG by id or returns 404
4. src/app/api/auth/route.ts — GET returns demoUsers (with optional role filter), POST returns 503
5. src/app/api/bookings/route.ts — GET returns demoBookings with image splitting, POST/PATCH return 503
6. src/app/api/payments/route.ts — GET returns demoPayments, POST/PUT return 503
7. src/app/api/complaints/route.ts — GET returns demoComplaints, POST/PUT return 503
8. src/app/api/vendors/route.ts — GET returns demoVendors, POST returns 503
9. src/app/api/workers/route.ts — GET returns demoWorkers, POST/PUT return 503
10. src/app/api/analytics/route.ts — GET returns demoAnalytics
11. src/app/api/setup/route.ts — GET returns demo-mode status
12. src/app/api/seed/route.ts — POST returns 503

Additional fix:
- src/lib/supabase.ts line 51: removed extra `)` in proxy get handler no-op chain that caused parse error

Stage Summary:
- 12 API route files updated with lazy Supabase client pattern
- 1 syntax error fixed in supabase.ts (pre-existing bug)
- All GET routes return demo data when Supabase is not configured
- All write routes (POST/PUT/PATCH) return 503 with descriptive error when Supabase is not configured
- Existing Supabase logic preserved unchanged when client IS available
- Verified all endpoints work in demo mode via curl tests:
  - GET /api → demo-mode ✓
  - GET /api/pgs → 6 demo PGs ✓
  - GET /api/pgs/demo-pg-1 → Sunrise PG with rooms ✓
  - GET /api/auth → 5 demo users ✓
  - GET /api/bookings?userId=demo-user-1 → 3 demo bookings ✓
  - GET /api/analytics?ownerId=demo-owner-1 → analytics data ✓
  - POST /api/pgs → 503 ✓
  - GET /api/setup → demo-mode status ✓
