import { createClient, SupabaseClient } from '@supabase/supabase-js';

let _supabase: SupabaseClient | null = null;

function getSupabaseClient(): SupabaseClient | null {
  if (_supabase) return _supabase;

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!supabaseUrl || !supabaseAnonKey) {
    console.warn(
      '[StayEg] Supabase not configured. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in your environment.'
    );
    return null;
  }

  _supabase = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
    },
    db: {
      schema: 'public',
    },
  });

  return _supabase;
}

/**
 * Lazy-initialized Supabase client.
 * Returns null if env vars are not set (graceful degradation).
 * Always check for null before using:
 *   const supabase = getSupabase();
 *   if (!supabase) return fallback;
 */
export function getSupabase(): SupabaseClient | null {
  return getSupabaseClient();
}

/** @deprecated Use getSupabase() instead — returns null when not configured */
export const supabase = new Proxy({} as SupabaseClient, {
  get(_target, prop) {
    const client = getSupabaseClient();
    if (!client) {
      // Return a no-op for common method chains so code doesn't crash on property access
      return (...args: any[]) => {
        console.warn(`[StayEg] Supabase call "${String(prop)}" skipped — not configured`);
        return { data: null, error: { message: 'Supabase not configured', code: 'NOT_CONFIGURED' }, then: () => {}, catch: () => {}, select: () => ({ from: () => ({ ...createNoopChain() }) }), from: () => createNoopChain() };
      };
    }
    const value = (client as any)[prop];
    return typeof value === 'function' ? value.bind(client) : value;
  },
});

function createNoopChain() {
  return {
    select: () => createNoopChain(),
    from: () => createNoopChain(),
    where: () => createNoopChain(),
    eq: () => createNoopChain(),
    neq: () => createNoopChain(),
    in: () => createNoopChain(),
    ilike: () => createNoopChain(),
    like: () => createNoopChain(),
    or: () => createNoopChain(),
    and: () => createNoopChain(),
    gte: () => createNoopChain(),
    lte: () => createNoopChain(),
    gt: () => createNoopChain(),
    lt: () => createNoopChain(),
    limit: () => createNoopChain(),
    order: () => createNoopChain(),
    single: () => createNoopChain(),
    insert: () => createNoopChain(),
    update: () => createNoopChain(),
    delete: () => createNoopChain(),
    upsert: () => createNoopChain(),
  };
}

export default supabase;
