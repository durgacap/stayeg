/**
 * Demo/fallback data for StayEg when Supabase is not configured.
 * This ensures the app is fully functional for preview and demo purposes.
 */

export const demoPGs = [
  {
    id: 'demo-pg-1',
    name: 'Sunrise PG',
    description: 'Premium PG accommodation in the heart of Bangalore with all modern amenities.',
    address: '123, HSR Layout, Sector 2, Bangalore - 560102',
    city: 'Bangalore',
    gender: 'UNISEX',
    price: 8000,
    security_deposit: 8000,
    rating: 4.5,
    is_verified: true,
    status: 'APPROVED',
    owner_id: 'demo-owner-1',
    amenities: 'WiFi,AC,Hot Water,Laundry,Meals,Parking,CCTV,Power Backup',
    images: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800,https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800,https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800',
    created_at: '2025-01-15T10:30:00Z',
    owner: { id: 'demo-owner-1', name: 'Rajesh Kumar', phone: '+91 98765 43210', avatar: null },
    rooms: [
      {
        id: 'demo-room-1', room_code: 'A101', room_type: 'DOUBLE', floor: 1, pg_id: 'demo-pg-1', capacity: 2,
        beds: [
          { id: 'demo-bed-1', bed_number: 'B1', room_id: 'demo-room-1', status: 'AVAILABLE', price: 8000 },
          { id: 'demo-bed-2', bed_number: 'B2', room_id: 'demo-room-1', status: 'OCCUPIED', price: 8000 },
        ],
      },
      {
        id: 'demo-room-2', room_code: 'A102', room_type: 'TRIPLE', floor: 1, pg_id: 'demo-pg-1', capacity: 3,
        beds: [
          { id: 'demo-bed-3', bed_number: 'B1', room_id: 'demo-room-2', status: 'AVAILABLE', price: 7500 },
          { id: 'demo-bed-4', bed_number: 'B2', room_id: 'demo-room-2', status: 'AVAILABLE', price: 7500 },
          { id: 'demo-bed-5', bed_number: 'B3', room_id: 'demo-room-2', status: 'OCCUPIED', price: 7500 },
        ],
      },
    ],
  },
  {
    id: 'demo-pg-2',
    name: 'Blue Heaven PG',
    description: 'Affordable and comfortable PG near Electronic City with great food and security.',
    address: '456, Electronic City Phase 1, Bangalore - 560100',
    city: 'Bangalore',
    gender: 'MALE',
    price: 5500,
    security_deposit: 5500,
    rating: 4.2,
    is_verified: true,
    status: 'APPROVED',
    owner_id: 'demo-owner-2',
    amenities: 'WiFi,Hot Water,Laundry,Meals,CCTV,Power Backup',
    images: 'https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=800,https://images.unsplash.com/photo-1560185893-a55cbc8c57e8?w=800',
    created_at: '2025-02-20T14:00:00Z',
    owner: { id: 'demo-owner-2', name: 'Priya Sharma', phone: '+91 87654 32109', avatar: null },
    rooms: [
      {
        id: 'demo-room-3', room_code: 'B201', room_type: 'TRIPLE', floor: 2, pg_id: 'demo-pg-2', capacity: 3,
        beds: [
          { id: 'demo-bed-6', bed_number: 'B1', room_id: 'demo-room-3', status: 'OCCUPIED', price: 5500 },
          { id: 'demo-bed-7', bed_number: 'B2', room_id: 'demo-room-3', status: 'OCCUPIED', price: 5500 },
          { id: 'demo-bed-8', bed_number: 'B3', room_id: 'demo-room-3', status: 'AVAILABLE', price: 5500 },
        ],
      },
    ],
  },
  {
    id: 'demo-pg-3',
    name: 'Green Valley Ladies PG',
    description: 'Safe and secure ladies PG in Koramangala with homely food and caring staff.',
    address: '789, Koramangala 4th Block, Bangalore - 560034',
    city: 'Bangalore',
    gender: 'FEMALE',
    price: 9000,
    security_deposit: 9000,
    rating: 4.8,
    is_verified: true,
    status: 'APPROVED',
    owner_id: 'demo-owner-1',
    amenities: 'WiFi,AC,Hot Water,Laundry,Meals,Parking,CCTV,Power Backup,Gym,Washing Machine',
    images: 'https://images.unsplash.com/photo-1630699144867-37acec97df5a?w=800,https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800',
    created_at: '2025-03-10T09:15:00Z',
    owner: { id: 'demo-owner-1', name: 'Rajesh Kumar', phone: '+91 98765 43210', avatar: null },
    rooms: [
      {
        id: 'demo-room-4', room_code: 'C301', room_type: 'DOUBLE', floor: 3, pg_id: 'demo-pg-3', capacity: 2,
        beds: [
          { id: 'demo-bed-9', bed_number: 'B1', room_id: 'demo-room-4', status: 'OCCUPIED', price: 9000 },
          { id: 'demo-bed-10', bed_number: 'B2', room_id: 'demo-room-4', status: 'AVAILABLE', price: 9000 },
        ],
      },
    ],
  },
  {
    id: 'demo-pg-4',
    name: 'Comfort Stay PG',
    description: 'Budget-friendly PG in Whitefield with clean rooms and friendly atmosphere.',
    address: '321, Whitefield Main Road, Bangalore - 560066',
    city: 'Bangalore',
    gender: 'MALE',
    price: 4500,
    security_deposit: 4500,
    rating: 3.9,
    is_verified: false,
    status: 'APPROVED',
    owner_id: 'demo-owner-2',
    amenities: 'WiFi,Hot Water,Meals,CCTV',
    images: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800',
    created_at: '2025-04-01T11:45:00Z',
    owner: { id: 'demo-owner-2', name: 'Priya Sharma', phone: '+91 87654 32109', avatar: null },
    rooms: [
      {
        id: 'demo-room-5', room_code: 'D101', room_type: 'FOUR_SHARING', floor: 1, pg_id: 'demo-pg-4', capacity: 4,
        beds: [
          { id: 'demo-bed-11', bed_number: 'B1', room_id: 'demo-room-5', status: 'OCCUPIED', price: 4500 },
          { id: 'demo-bed-12', bed_number: 'B2', room_id: 'demo-room-5', status: 'OCCUPIED', price: 4500 },
          { id: 'demo-bed-13', bed_number: 'B3', room_id: 'demo-room-5', status: 'AVAILABLE', price: 4500 },
          { id: 'demo-bed-14', bed_number: 'B4', room_id: 'demo-room-5', status: 'AVAILABLE', price: 4500 },
        ],
      },
    ],
  },
  {
    id: 'demo-pg-5',
    name: 'Royal Residency PG',
    description: 'Luxury PG in Indiranagar with premium amenities and 24/7 concierge service.',
    address: '555, Indiranagar 100 Ft Road, Bangalore - 560038',
    city: 'Bangalore',
    gender: 'UNISEX',
    price: 12000,
    security_deposit: 12000,
    rating: 4.6,
    is_verified: true,
    status: 'APPROVED',
    owner_id: 'demo-owner-1',
    amenities: 'WiFi,AC,Hot Water,Laundry,Meals,Parking,CCTV,Power Backup,Gym,Swimming Pool,Recreation Room',
    images: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800,https://images.unsplash.com/photo-1560185007-cde436f6a4d0?w=800',
    created_at: '2025-05-15T16:20:00Z',
    owner: { id: 'demo-owner-1', name: 'Rajesh Kumar', phone: '+91 98765 43210', avatar: null },
    rooms: [
      {
        id: 'demo-room-6', room_code: 'E401', room_type: 'SINGLE', floor: 4, pg_id: 'demo-pg-5', capacity: 1,
        beds: [
          { id: 'demo-bed-15', bed_number: 'B1', room_id: 'demo-room-6', status: 'AVAILABLE', price: 12000 },
        ],
      },
      {
        id: 'demo-room-7', room_code: 'E402', room_type: 'DOUBLE', floor: 4, pg_id: 'demo-pg-5', capacity: 2,
        beds: [
          { id: 'demo-bed-16', bed_number: 'B1', room_id: 'demo-room-7', status: 'OCCUPIED', price: 11000 },
          { id: 'demo-bed-17', bed_number: 'B2', room_id: 'demo-room-7', status: 'OCCUPIED', price: 11000 },
        ],
      },
    ],
  },
  {
    id: 'demo-pg-6',
    name: 'Metro Living PG',
    description: 'Well-located PG near MG Road metro station. Perfect for working professionals.',
    address: '77, MG Road, Bangalore - 560001',
    city: 'Bangalore',
    gender: 'MALE',
    price: 7000,
    security_deposit: 7000,
    rating: 4.1,
    is_verified: true,
    status: 'APPROVED',
    owner_id: 'demo-owner-2',
    amenities: 'WiFi,AC,Hot Water,Laundry,Meals,CCTV,Power Backup',
    images: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',
    created_at: '2025-06-01T08:00:00Z',
    owner: { id: 'demo-owner-2', name: 'Priya Sharma', phone: '+91 87654 32109', avatar: null },
    rooms: [
      {
        id: 'demo-room-8', room_code: 'F201', room_type: 'TRIPLE', floor: 2, pg_id: 'demo-pg-6', capacity: 3,
        beds: [
          { id: 'demo-bed-18', bed_number: 'B1', room_id: 'demo-room-8', status: 'OCCUPIED', price: 7000 },
          { id: 'demo-bed-19', bed_number: 'B2', room_id: 'demo-room-8', status: 'AVAILABLE', price: 7000 },
          { id: 'demo-bed-20', bed_number: 'B3', room_id: 'demo-room-8', status: 'AVAILABLE', price: 7000 },
        ],
      },
    ],
  },
];

export const demoBookings = [
  {
    id: 'demo-booking-1', user_id: 'demo-user-1', pg_id: 'demo-pg-1', bed_id: 'demo-bed-2',
    check_in_date: '2025-02-01T00:00:00Z', advance_paid: 8000, status: 'ACTIVE',
    created_at: '2025-01-25T10:00:00Z',
    pg: { id: 'demo-pg-1', name: 'Sunrise PG', address: '123, HSR Layout', city: 'Bangalore', images: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=800' },
    bed: { id: 'demo-bed-2', bed_number: 'B2', status: 'OCCUPIED', room: { room_code: 'A101', room_type: 'DOUBLE', floor: 1 } },
    user: { id: 'demo-user-1', name: 'Amit Patel', email: 'amit@example.com', phone: '+91 99887 76655', avatar: null },
    payments: [{ id: 'demo-pay-1', amount: 8000, status: 'COMPLETED', type: 'RENT', method: 'UPI' }],
  },
  {
    id: 'demo-booking-2', user_id: 'demo-user-2', pg_id: 'demo-pg-2', bed_id: 'demo-bed-6',
    check_in_date: '2025-03-15T00:00:00Z', advance_paid: 5500, status: 'ACTIVE',
    created_at: '2025-03-10T08:30:00Z',
    pg: { id: 'demo-pg-2', name: 'Blue Heaven PG', address: '456, Electronic City', city: 'Bangalore', images: 'https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=800' },
    bed: { id: 'demo-bed-6', bed_number: 'B1', status: 'OCCUPIED', room: { room_code: 'B201', room_type: 'TRIPLE', floor: 2 } },
    user: { id: 'demo-user-2', name: 'Sneha Gupta', email: 'sneha@example.com', phone: '+91 88776 65544', avatar: null },
    payments: [],
  },
  {
    id: 'demo-booking-3', user_id: 'demo-user-3', pg_id: 'demo-pg-3', bed_id: 'demo-bed-9',
    check_in_date: '2025-04-01T00:00:00Z', advance_paid: 9000, status: 'CONFIRMED',
    created_at: '2025-03-20T14:00:00Z',
    pg: { id: 'demo-pg-3', name: 'Green Valley Ladies PG', address: '789, Koramangala', city: 'Bangalore', images: 'https://images.unsplash.com/photo-1630699144867-37acec97df5a?w=800' },
    bed: { id: 'demo-bed-9', bed_number: 'B1', status: 'OCCUPIED', room: { room_code: 'C301', room_type: 'DOUBLE', floor: 3 } },
    user: { id: 'demo-user-3', name: 'Kavitha Ramesh', email: 'kavitha@example.com', phone: '+91 77665 54433', avatar: null },
    payments: [{ id: 'demo-pay-2', amount: 9000, status: 'COMPLETED', type: 'RENT', method: 'BANK_TRANSFER' }],
  },
];

export const demoPayments = [
  { id: 'demo-pay-1', user_id: 'demo-user-1', pg_id: 'demo-pg-1', booking_id: 'demo-booking-1', amount: 8000, type: 'RENT', method: 'UPI', status: 'COMPLETED', paid_date: '2025-02-01T00:00:00Z', created_at: '2025-02-01T00:00:00Z', pg: { id: 'demo-pg-1', name: 'Sunrise PG' }, user: { id: 'demo-user-1', name: 'Amit Patel', email: 'amit@example.com', phone: '+91 99887 76655', avatar: null } },
  { id: 'demo-pay-2', user_id: 'demo-user-3', pg_id: 'demo-pg-3', booking_id: 'demo-booking-3', amount: 9000, type: 'RENT', method: 'BANK_TRANSFER', status: 'COMPLETED', paid_date: '2025-04-01T00:00:00Z', created_at: '2025-04-01T00:00:00Z', pg: { id: 'demo-pg-3', name: 'Green Valley Ladies PG' }, user: { id: 'demo-user-3', name: 'Kavitha Ramesh', email: 'kavitha@example.com', phone: '+91 77665 54433', avatar: null } },
  { id: 'demo-pay-3', user_id: 'demo-user-2', pg_id: 'demo-pg-2', booking_id: 'demo-booking-2', amount: 5500, type: 'RENT', method: 'CASH', status: 'PENDING', paid_date: null, created_at: '2025-04-01T00:00:00Z', pg: { id: 'demo-pg-2', name: 'Blue Heaven PG' }, user: { id: 'demo-user-2', name: 'Sneha Gupta', email: 'sneha@example.com', phone: '+91 88776 65544', avatar: null } },
  { id: 'demo-pay-4', user_id: 'demo-user-1', pg_id: 'demo-pg-1', booking_id: 'demo-booking-1', amount: 8000, type: 'RENT', method: 'UPI', status: 'COMPLETED', paid_date: '2025-03-01T00:00:00Z', created_at: '2025-03-01T00:00:00Z', pg: { id: 'demo-pg-1', name: 'Sunrise PG' }, user: { id: 'demo-user-1', name: 'Amit Patel', email: 'amit@example.com', phone: '+91 99887 76655', avatar: null } },
  { id: 'demo-pay-5', user_id: 'demo-user-1', pg_id: 'demo-pg-1', booking_id: 'demo-booking-1', amount: 8000, type: 'RENT', method: 'UPI', status: 'COMPLETED', paid_date: '2025-04-01T00:00:00Z', created_at: '2025-04-01T00:00:00Z', pg: { id: 'demo-pg-1', name: 'Sunrise PG' }, user: { id: 'demo-user-1', name: 'Amit Patel', email: 'amit@example.com', phone: '+91 99887 76655', avatar: null } },
];

export const demoComplaints = [
  { id: 'demo-complaint-1', user_id: 'demo-user-1', pg_id: 'demo-pg-1', title: 'WiFi not working', description: 'WiFi has been down since yesterday evening. Please fix it as soon as possible.', category: 'INFRASTRUCTURE', priority: 'HIGH', status: 'IN_PROGRESS', created_at: '2025-04-10T08:00:00Z', pg: { id: 'demo-pg-1', name: 'Sunrise PG' }, user: { id: 'demo-user-1', name: 'Amit Patel', email: 'amit@example.com', phone: '+91 99887 76655', avatar: null } },
  { id: 'demo-complaint-2', user_id: 'demo-user-2', pg_id: 'demo-pg-2', title: 'Water heater broken', description: 'The water heater in my bathroom is not working. Cold water only.', category: 'INFRASTRUCTURE', priority: 'MEDIUM', status: 'OPEN', created_at: '2025-04-12T10:30:00Z', pg: { id: 'demo-pg-2', name: 'Blue Heaven PG' }, user: { id: 'demo-user-2', name: 'Sneha Gupta', email: 'sneha@example.com', phone: '+91 88776 65544', avatar: null } },
  { id: 'demo-complaint-3', user_id: 'demo-user-3', pg_id: 'demo-pg-3', title: 'Loud noise at night', description: 'Construction noise from nearby site continues late into the night.', category: 'GENERAL', priority: 'LOW', status: 'RESOLVED', resolution: 'Spoke with the construction team. They agreed to stop work by 9 PM.', created_at: '2025-04-05T19:00:00Z', pg: { id: 'demo-pg-3', name: 'Green Valley Ladies PG' }, user: { id: 'demo-user-3', name: 'Kavitha Ramesh', email: 'kavitha@example.com', phone: '+91 77665 54433', avatar: null } },
];

export const demoVendors = [
  { id: 'demo-vendor-1', name: 'Fresh Meal Services', type: 'FOOD', phone: '+91 99887 76655', email: 'freshmeals@example.com', city: 'Bangalore', area: 'HSR Layout', rating: 4.3 },
  { id: 'demo-vendor-2', name: 'QuickFix Maintenance', type: 'MAINTENANCE', phone: '+91 88776 65544', email: 'quickfix@example.com', city: 'Bangalore', area: 'Koramangala', rating: 4.0 },
  { id: 'demo-vendor-3', name: 'Sparkle Clean Solutions', type: 'CLEANING', phone: '+91 77665 54433', email: 'sparkle@example.com', city: 'Bangalore', area: 'Whitefield', rating: 4.5 },
  { id: 'demo-vendor-4', name: 'SecureGuard Agency', type: 'SECURITY', phone: '+91 66554 43322', email: 'secureguard@example.com', city: 'Bangalore', area: 'Electronic City', rating: 4.2 },
  { id: 'demo-vendor-5', name: 'LaundroMax', type: 'LAUNDRY', phone: '+91 55443 32211', email: 'laundromax@example.com', city: 'Bangalore', area: 'Indiranagar', rating: 3.8 },
];

export const demoWorkers = [
  { id: 'demo-worker-1', name: 'Ramu', role: 'HOUSEKEEPING', phone: '+91 99887 76655', pg_id: 'demo-pg-1', shift: 'MORNING', status: 'ACTIVE' },
  { id: 'demo-worker-2', name: 'Suresh', role: 'SECURITY', phone: '+91 88776 65544', pg_id: 'demo-pg-1', shift: 'NIGHT', status: 'ACTIVE' },
  { id: 'demo-worker-3', name: 'Lakshmi', role: 'COOK', phone: '+91 77665 54433', pg_id: 'demo-pg-2', shift: 'MORNING', status: 'ACTIVE' },
  { id: 'demo-worker-4', name: 'Murugan', role: 'MAINTENANCE', phone: '+91 66554 43322', pg_id: 'demo-pg-3', shift: 'FULL_TIME', status: 'ACTIVE' },
];

export const demoUsers = [
  { id: 'demo-user-1', name: 'Amit Patel', email: 'amit@example.com', phone: '+91 99887 76655', role: 'TENANT', avatar: null, gender: 'MALE', is_verified: true, created_at: '2025-01-20T10:00:00Z' },
  { id: 'demo-user-2', name: 'Sneha Gupta', email: 'sneha@example.com', phone: '+91 88776 65544', role: 'TENANT', avatar: null, gender: 'FEMALE', is_verified: true, created_at: '2025-02-15T11:30:00Z' },
  { id: 'demo-user-3', name: 'Kavitha Ramesh', email: 'kavitha@example.com', phone: '+91 77665 54433', role: 'TENANT', avatar: null, gender: 'FEMALE', is_verified: true, created_at: '2025-03-10T09:00:00Z' },
  { id: 'demo-owner-1', name: 'Rajesh Kumar', email: 'rajesh@example.com', phone: '+91 98765 43210', role: 'OWNER', avatar: null, gender: 'MALE', is_verified: true, created_at: '2025-01-01T08:00:00Z' },
  { id: 'demo-owner-2', name: 'Priya Sharma', email: 'priya@example.com', phone: '+91 87654 32109', role: 'OWNER', avatar: null, gender: 'FEMALE', is_verified: true, created_at: '2025-01-05T14:00:00Z' },
];

export const demoAnalytics = {
  totalPGs: 4,
  totalRooms: 8,
  totalBeds: 20,
  occupiedBeds: 7,
  availableBeds: 13,
  occupancyRate: 35,
  monthlyRevenue: 32500,
  pendingPayments: 1,
  pendingAmount: 5500,
  totalTenants: 7,
  activeBookings: 3,
  revenueTrend: [
    { month: 'Jan', revenue: 8000 },
    { month: 'Feb', revenue: 8000 },
    { month: 'Mar', revenue: 17000 },
    { month: 'Apr', revenue: 17000 },
    { month: 'May', revenue: 32500 },
    { month: 'Jun', revenue: 25000 },
  ],
  genderDistribution: { male: 2, female: 1, unisex: 1 },
  openComplaints: 2,
};
