import { getSupabase } from '@/lib/supabase';
import { demoComplaints } from '@/lib/demo-data';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const supabase = getSupabase();
  if (!supabase) {
    return NextResponse.json(demoComplaints);
  }

  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const pgId = searchParams.get('pgId');
    const status = searchParams.get('status');

    let query = supabase
      .from('complaints')
      .select('*, pg:pgs(id,name), user:users(id,name,email,phone,avatar)')
      .order('created_at', { ascending: false });

    if (userId) query = query.eq('user_id', userId);
    if (pgId) query = query.eq('pg_id', pgId);
    if (status) query = query.eq('status', status);

    const { data: complaints, error } = await query;
    if (error) throw error;

    return NextResponse.json(complaints || []);
  } catch (error) {
    console.error('Error fetching complaints:', error);
    return NextResponse.json({ error: 'Failed to fetch complaints' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const supabase = getSupabase();
  if (!supabase) {
    return NextResponse.json({ error: 'Database not configured. Add Supabase env vars to enable writes.' }, { status: 503 });
  }

  try {
    const body = await request.json();
    const { userId, pgId, title, description, category, priority } = body;

    if (!userId || !pgId || !title) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const { data: complaint, error } = await supabase
      .from('complaints')
      .insert({
        user_id: userId,
        pg_id: pgId,
        title,
        description,
        category: category || 'GENERAL',
        priority: priority || 'MEDIUM',
      })
      .select('*, pg:pgs(name)')
      .single();

    if (error) throw error;
    return NextResponse.json(complaint, { status: 201 });
  } catch (error) {
    console.error('Error creating complaint:', error);
    return NextResponse.json({ error: 'Failed to create complaint' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const supabase = getSupabase();
  if (!supabase) {
    return NextResponse.json({ error: 'Database not configured. Add Supabase env vars to enable writes.' }, { status: 503 });
  }

  try {
    const body = await request.json();
    const { id, status, assignedTo, resolution } = body;
    if (!id) {
      return NextResponse.json({ error: 'id is required' }, { status: 400 });
    }
    const updateData: Record<string, unknown> = {};
    if (status) updateData.status = status;
    if (assignedTo !== undefined) updateData.assigned_to = assignedTo;
    if (resolution !== undefined) updateData.resolution = resolution;

    const { data: complaint, error } = await supabase
      .from('complaints')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return NextResponse.json(complaint);
  } catch (error) {
    console.error('Error updating complaint:', error);
    return NextResponse.json({ error: 'Failed to update complaint' }, { status: 500 });
  }
}
