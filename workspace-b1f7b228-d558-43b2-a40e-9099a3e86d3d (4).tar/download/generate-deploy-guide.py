import os
import hashlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch, cm
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, CondPageBreak, Flowable
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.platypus.tableofcontents import TableOfContents

# ━━ Color Palette (Cascade) ━━
ACCENT        = colors.HexColor('#6c4ec8')
ACCENT2       = colors.HexColor('#30c078')
TEXT_PRIMARY   = colors.HexColor('#272623')
TEXT_MUTED     = colors.HexColor('#84827a')
BG_PAGE       = colors.HexColor('#f2f1f0')
BG_SURFACE    = colors.HexColor('#ecebe9')
TABLE_HEADER   = colors.HexColor('#696045')
TABLE_STRIPE   = colors.HexColor('#f2f1ef')
BORDER_COLOR   = colors.HexColor('#c1bba9')

# ━━ Font Registration ━━
pdfmetrics.registerFont(TTFont('TimesNewRoman', '/usr/share/fonts/truetype/english/Times-New-Roman.ttf'))
pdfmetrics.registerFont(TTFont('Calibri', '/usr/share/fonts/truetype/english/calibri-regular.ttf'))
pdfmetrics.registerFont(TTFont('SimHei', '/usr/share/fonts/truetype/chinese/SimHei.ttf'))
pdfmetrics.registerFont(TTFont('DejaVuSans', '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'))
registerFontFamily('TimesNewRoman', normal='TimesNewRoman', bold='TimesNewRoman')
registerFontFamily('Calibri', normal='Calibri', bold='Calibri')
registerFontFamily('SimHei', normal='SimHei', bold='SimHei')
registerFontFamily('DejaVuSans', normal='DejaVuSans', bold='DejaVuSans')

# ━━ Styles ━━
PAGE_W, PAGE_H = A4
LEFT_M = 1.0 * inch
RIGHT_M = 1.0 * inch
TOP_M = 0.8 * inch
BOT_M = 0.8 * inch
AVAIL_W = PAGE_W - LEFT_M - RIGHT_M

styles = getSampleStyleSheet()

title_style = ParagraphStyle(
    name='DocTitle', fontName='TimesNewRoman', fontSize=28,
    leading=36, textColor=TEXT_PRIMARY, alignment=TA_LEFT,
    spaceAfter=6, spaceBefore=0
)
subtitle_style = ParagraphStyle(
    name='DocSubtitle', fontName='Calibri', fontSize=14,
    leading=20, textColor=TEXT_MUTED, alignment=TA_LEFT,
    spaceAfter=12
)
h1_style = ParagraphStyle(
    name='H1', fontName='TimesNewRoman', fontSize=20,
    leading=28, textColor=ACCENT, alignment=TA_LEFT,
    spaceBefore=18, spaceAfter=10
)
h2_style = ParagraphStyle(
    name='H2', fontName='TimesNewRoman', fontSize=15,
    leading=22, textColor=TEXT_PRIMARY, alignment=TA_LEFT,
    spaceBefore=14, spaceAfter=8
)
h3_style = ParagraphStyle(
    name='H3', fontName='TimesNewRoman', fontSize=12,
    leading=18, textColor=TABLE_HEADER, alignment=TA_LEFT,
    spaceBefore=10, spaceAfter=6
)
body_style = ParagraphStyle(
    name='Body', fontName='TimesNewRoman', fontSize=10.5,
    leading=17, textColor=TEXT_PRIMARY, alignment=TA_JUSTIFY,
    spaceBefore=0, spaceAfter=6
)
body_left = ParagraphStyle(
    name='BodyLeft', fontName='TimesNewRoman', fontSize=10.5,
    leading=17, textColor=TEXT_PRIMARY, alignment=TA_LEFT,
    spaceBefore=0, spaceAfter=6
)
code_style = ParagraphStyle(
    name='Code', fontName='DejaVuSans', fontSize=8.5,
    leading=13, textColor=colors.HexColor('#2d2d2d'),
    backColor=colors.HexColor('#f5f3ef'),
    borderColor=BORDER_COLOR, borderWidth=0.5,
    borderPadding=6, leftIndent=12, rightIndent=12,
    spaceBefore=4, spaceAfter=8
)
bullet_style = ParagraphStyle(
    name='Bullet', fontName='TimesNewRoman', fontSize=10.5,
    leading=17, textColor=TEXT_PRIMARY, alignment=TA_LEFT,
    leftIndent=24, bulletIndent=12, spaceBefore=2, spaceAfter=2,
    bulletFontName='TimesNewRoman', bulletFontSize=10.5
)
note_style = ParagraphStyle(
    name='Note', fontName='Calibri', fontSize=9.5,
    leading=15, textColor=TABLE_HEADER, alignment=TA_LEFT,
    leftIndent=18, rightIndent=18, spaceBefore=6, spaceAfter=6,
    backColor=colors.HexColor('#faf8f3'), borderColor=ACCENT,
    borderWidth=1, borderPadding=8
)
header_cell = ParagraphStyle(
    name='HeaderCell', fontName='TimesNewRoman', fontSize=10,
    leading=14, textColor=colors.white, alignment=TA_CENTER
)
cell_style = ParagraphStyle(
    name='Cell', fontName='TimesNewRoman', fontSize=9.5,
    leading=14, textColor=TEXT_PRIMARY, alignment=TA_LEFT
)
cell_center = ParagraphStyle(
    name='CellCenter', fontName='TimesNewRoman', fontSize=9.5,
    leading=14, textColor=TEXT_PRIMARY, alignment=TA_CENTER
)

# ━━ TOC Template ━━
class TocDocTemplate(SimpleDocTemplate):
    def afterFlowable(self, flowable):
        if hasattr(flowable, 'bookmark_name'):
            level = getattr(flowable, 'bookmark_level', 0)
            text = getattr(flowable, 'bookmark_text', '')
            key = getattr(flowable, 'bookmark_key', '')
            self.notify('TOCEntry', (level, text, self.page, key))

def add_heading(text, style, level=0):
    key = 'h_%s' % hashlib.md5(text.encode()).hexdigest()[:8]
    p = Paragraph('<a name="%s"/>%s' % (key, text), style)
    p.bookmark_name = text
    p.bookmark_level = level
    p.bookmark_text = text
    p.bookmark_key = key
    return p

# ━━ Separator Line ━━
class HRLine(Flowable):
    def __init__(self, width, color=BORDER_COLOR, thickness=0.5):
        Flowable.__init__(self)
        self.width = width
        self.color = color
        self.thickness = thickness
        self.height = thickness + 4
    def draw(self):
        self.canv.setStrokeColor(self.color)
        self.canv.setLineWidth(self.thickness)
        self.canv.line(0, 2, self.width, 2)

# ━━ Build Document ━━
output_path = '/home/z/my-project/download/StayEg-Vercel-Deployment-Guide.pdf'

doc = TocDocTemplate(
    output_path, pagesize=A4,
    leftMargin=LEFT_M, rightMargin=RIGHT_M,
    topMargin=TOP_M, bottomMargin=BOT_M,
    title='StayEg - Vercel Deployment Guide',
    author='StayEg Team', creator='Z.ai'
)

story = []

# ── Cover Page ──
story.append(Spacer(1, 120))
story.append(HRLine(AVAIL_W, ACCENT, 2))
story.append(Spacer(1, 30))
story.append(Paragraph('<b>StayEg</b>', title_style))
story.append(Paragraph('Vercel Deployment Guide', ParagraphStyle(
    name='CoverSub', fontName='TimesNewRoman', fontSize=22,
    leading=30, textColor=ACCENT, alignment=TA_LEFT, spaceAfter=8
)))
story.append(Spacer(1, 12))
story.append(Paragraph('Step-by-step instructions to deploy your StayEg application<br/>'
    '(India\'s Smart PG Ecosystem) to Vercel and make it live on the internet.',
    ParagraphStyle(name='CoverDesc', fontName='Calibri', fontSize=12,
        leading=20, textColor=TEXT_MUTED, alignment=TA_LEFT)))
story.append(Spacer(1, 30))
story.append(HRLine(AVAIL_W, BORDER_COLOR, 0.5))
story.append(Spacer(1, 24))
meta_style = ParagraphStyle(name='Meta', fontName='Calibri', fontSize=10,
    leading=16, textColor=TEXT_MUTED, alignment=TA_LEFT)
story.append(Paragraph('Tech Stack: Next.js 16 + Tailwind CSS 4 + Supabase', meta_style))
story.append(Paragraph('Date: April 2026', meta_style))
story.append(Paragraph('Version: 1.0', meta_style))
story.append(PageBreak())

# ── Table of Contents ──
story.append(Paragraph('<b>Table of Contents</b>', ParagraphStyle(
    name='TOCTitle', fontName='TimesNewRoman', fontSize=20,
    leading=28, textColor=TEXT_PRIMARY, alignment=TA_LEFT, spaceAfter=12
)))
toc = TableOfContents()
toc.levelStyles = [
    ParagraphStyle(name='TOC1', fontName='TimesNewRoman', fontSize=12,
        leading=20, leftIndent=20, spaceBefore=4, spaceAfter=2),
    ParagraphStyle(name='TOC2', fontName='TimesNewRoman', fontSize=10.5,
        leading=18, leftIndent=40, spaceBefore=2, spaceAfter=2),
]
story.append(toc)
story.append(PageBreak())

# ═══════════════════════════════════════════════════════════
# SECTION 1: Overview
# ═══════════════════════════════════════════════════════════
story.extend([
    add_heading('<b>1. Overview</b>', h1_style, 0),
    Paragraph(
        'This guide walks you through deploying your StayEg application (India\'s Smart PG Ecosystem) to Vercel, '
        'a popular hosting platform that makes Next.js applications live on the internet in minutes. You do not need '
        'any prior development experience to follow these steps. Each step includes exact clicks, commands, and '
        'screenshots descriptions to help you along the way. The entire process takes approximately 15 to 20 minutes.',
        body_style),
    Paragraph(
        'Your application is built with Next.js 16 (the latest version), Tailwind CSS 4 for styling, and Supabase '
        'for the database. Vercel is built by the same team that created Next.js, so it provides the best possible '
        'hosting experience with automatic deployments, free SSL certificates, and a global content delivery network '
        '(CDN) that makes your website fast for users anywhere in India or around the world.',
        body_style),
    Paragraph(
        'Before starting, you should have your Supabase project credentials ready: the Supabase URL and the Anon Key. '
        'If you do not have these, you can find them in your Supabase project dashboard under Settings then API. These '
        'two values are the only environment variables your application needs to connect to the database on Vercel.',
        body_style),
    Spacer(1, 6),
    Paragraph('<b>What this guide covers:</b>', body_left),
    Paragraph('1. Creating a GitHub repository and pushing your code', bullet_style, bulletText='-'),
    Paragraph('2. Connecting your GitHub account to Vercel', bullet_style, bulletText='-'),
    Paragraph('3. Deploying the application with one click', bullet_style, bulletText='-'),
    Paragraph('4. Adding Supabase environment variables', bullet_style, bulletText='-'),
    Paragraph('5. Verifying the deployment works correctly', bullet_style, bulletText='-'),
    Paragraph('6. Troubleshooting common issues', bullet_style, bulletText='-'),
])

# ═══════════════════════════════════════════════════════════
# SECTION 2: Pre-Deployment Checklist
# ═══════════════════════════════════════════════════════════
story.extend([
    Spacer(1, 12),
    add_heading('<b>2. Pre-Deployment Checklist</b>', h1_style, 0),
    Paragraph(
        'Before deploying, make sure you have completed the following checklist. These are prerequisites that must '
        'be in place before you can successfully deploy your application. Missing any of these items will cause the '
        'deployment to fail or the app to not work properly after deployment.',
        body_style),
    Spacer(1, 12),
])

checklist_data = [
    [Paragraph('<b>Item</b>', header_cell),
     Paragraph('<b>Status</b>', header_cell),
     Paragraph('<b>How to Get It</b>', header_cell)],
    [Paragraph('GitHub Account', cell_style),
     Paragraph('Required', cell_center),
     Paragraph('Sign up free at github.com', cell_style)],
    [Paragraph('Vercel Account', cell_style),
     Paragraph('Required', cell_center),
     Paragraph('Sign up free at vercel.com (use GitHub login)', cell_style)],
    [Paragraph('Supabase URL', cell_style),
     Paragraph('Required', cell_center),
     Paragraph('Supabase Dashboard -> Settings -> API -> Project URL', cell_style)],
    [Paragraph('Supabase Anon Key', cell_style),
     Paragraph('Required', cell_center),
     Paragraph('Supabase Dashboard -> Settings -> API -> Project API keys (anon public)', cell_style)],
    [Paragraph('Git installed (local)', cell_style),
     Paragraph('Required', cell_center),
     Paragraph('Already installed on your development machine', cell_style)],
]

checklist_table = Table(checklist_data, colWidths=[AVAIL_W*0.22, AVAIL_W*0.15, AVAIL_W*0.63], hAlign='CENTER')
checklist_table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEADER),
    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
    *[('BACKGROUND', (0, i), (-1, i), TABLE_STRIPE if i % 2 == 0 else colors.white) for i in range(1, 6)],
    ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ('LEFTPADDING', (0, 0), (-1, -1), 8),
    ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ('TOPPADDING', (0, 0), (-1, -1), 6),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
]))
story.append(checklist_table)

story.append(Spacer(1, 10))
story.append(Paragraph(
    '<b>Important:</b> Your Supabase URL looks like: <b>https://xxxxx.supabase.co</b><br/>'
    'Your Supabase Anon Key is a long string starting with "eyJ..."',
    note_style))

# ═══════════════════════════════════════════════════════════
# SECTION 3: Push Code to GitHub
# ═══════════════════════════════════════════════════════════
story.extend([
    Spacer(1, 18),
    add_heading('<b>3. Push Your Code to GitHub</b>', h1_style, 0),
    Paragraph(
        'The first step is to upload your project code to GitHub. GitHub is a code hosting platform where Vercel will '
        'read your code from. Think of GitHub as a safe online storage for your code. When you push code to GitHub, '
        'Vercel can automatically detect changes and redeploy your application.',
        body_style),

    add_heading('<b>3.1 Create a New GitHub Repository</b>', h2_style, 1),
    Paragraph(
        'Open your web browser and go to <b>https://github.com/new</b>. You will see a form to create a new repository. '
        'Follow these exact steps to fill in the form:',
        body_style),
    Paragraph('1. In the "Repository name" field, type: <b>stayeg</b>', bullet_style, bulletText='-'),
    Paragraph('2. In the "Description" field, type: <b>StayEg - India\'s Smart PG Ecosystem</b>', bullet_style, bulletText='-'),
    Paragraph('3. Choose <b>Private</b> (recommended - keeps your code hidden from others)', bullet_style, bulletText='-'),
    Paragraph('4. Do NOT check "Add a README file" (we already have one)', bullet_style, bulletText='-'),
    Paragraph('5. Do NOT check "Add .gitignore" or "Choose a license"', bullet_style, bulletText='-'),
    Paragraph('6. Click the green <b>"Create repository"</b> button', bullet_style, bulletText='-'),
    Paragraph(
        'After clicking, GitHub will show you a page with some commands. Ignore those commands and follow the steps '
        'below instead, because your project is already set up with Git.',
        body_style),

    add_heading('<b>3.2 Push Your Existing Project to GitHub</b>', h2_style, 1),
    Paragraph(
        'Open your terminal (Command Prompt on Windows, Terminal on Mac/Linux) and navigate to your project folder. '
        'Then run the following commands one by one. Copy and paste each command, press Enter, and wait for it to finish '
        'before moving to the next one.',
        body_style),
])

# Code block styling helper
def code_block(text):
    return Paragraph(text.replace('\n', '<br/>').replace(' ', '&nbsp;'), code_style)

story.append(code_block(
    '# Step 1: Go to your project folder\n'
    'cd /path/to/your/stayeg-project\n\n'
    '# Step 2: Add all your files to Git\n'
    'git add .\n\n'
    '# Step 3: Save a snapshot of your code\n'
    'git commit -m "Initial commit - StayEg ready for deployment"\n\n'
    '# Step 4: Link your local project to GitHub\n'
    '# Replace YOUR_USERNAME with your actual GitHub username\n'
    'git remote add origin https://github.com/YOUR_USERNAME/stayeg.git\n\n'
    '# Step 5: Upload your code to GitHub\n'
    'git branch -M main\n'
    'git push -u origin main'
))

story.append(Spacer(1, 8))
story.append(Paragraph(
    '<b>Replace YOUR_USERNAME</b> in the command above with your actual GitHub username. '
    'For example, if your GitHub profile is github.com/johndoe, then use johndoe.',
    note_style))
story.append(Paragraph(
    'When you run <b>git push</b>, GitHub may ask you to log in. Follow the on-screen instructions. '
    'If it asks for a password, you need to use a Personal Access Token (PAT) instead of your password. '
    'Go to GitHub Settings -> Developer settings -> Personal access tokens -> Generate new token. '
    'Check "repo" scope and copy the token. Use this token as your password.',
    body_style))
story.append(Paragraph(
    'After the push completes successfully, go to <b>https://github.com/YOUR_USERNAME/stayeg</b> in your browser. '
    'You should see all your project files there. If you can see them, your code is on GitHub and you are ready '
    'for the next step.',
    body_style))

# ═══════════════════════════════════════════════════════════
# SECTION 4: Connect GitHub to Vercel
# ═══════════════════════════════════════════════════════════
story.extend([
    Spacer(1, 18),
    add_heading('<b>4. Connect GitHub to Vercel</b>', h1_style, 0),
    Paragraph(
        'Now that your code is on GitHub, the next step is to connect your GitHub account to Vercel. This allows Vercel '
        'to automatically read your code and deploy it every time you make changes. This connection is the backbone of '
        'modern web deployment, enabling a workflow called "continuous deployment" where every code push results in '
        'an automatic update to your live website.',
        body_style),

    add_heading('<b>4.1 Create a Vercel Account</b>', h2_style, 1),
    Paragraph(
        'If you do not already have a Vercel account, follow these steps to create one. Vercel offers a generous free '
        'tier that is more than enough for your StayEg application:',
        body_style),
    Paragraph('1. Open your browser and go to <b>https://vercel.com/signup</b>', bullet_style, bulletText='-'),
    Paragraph('2. Click <b>"Continue with GitHub"</b> (recommended and easiest)', bullet_style, bulletText='-'),
    Paragraph('3. Authorize Vercel to access your GitHub account when prompted', bullet_style, bulletText='-'),
    Paragraph('4. Fill in your name and email, then click <b>"Sign Up"</b>', bullet_style, bulletText='-'),
    Paragraph('5. Choose the <b>Hobby plan</b> (free) when asked', bullet_style, bulletText='-'),
    Paragraph(
        'Using GitHub to sign up automatically connects your GitHub account to Vercel, which saves you a step. '
        'If you used email to sign up instead, you will need to manually connect GitHub in the Vercel dashboard '
        'under Settings then Connections.',
        body_style),

    add_heading('<b>4.2 Import Your StayEg Repository</b>', h2_style, 1),
    Paragraph(
        'Now let us import your project into Vercel. This tells Vercel which GitHub repository to deploy:',
        body_style),
    Paragraph('1. Go to <b>https://vercel.com/new</b> in your browser', bullet_style, bulletText='-'),
    Paragraph('2. Under "Import Git Repository", you should see your <b>stayeg</b> repository listed', bullet_style, bulletText='-'),
    Paragraph('3. If you do not see it, click <b>"Adjust GitHub App Permissions"</b> and grant access to the stayeg repo', bullet_style, bulletText='-'),
    Paragraph('4. Click the <b>"Import"</b> button next to your stayeg repository', bullet_style, bulletText='-'),
])

# ═══════════════════════════════════════════════════════════
# SECTION 5: Configure and Deploy
# ═══════════════════════════════════════════════════════════
story.extend([
    Spacer(1, 18),
    add_heading('<b>5. Configure and Deploy</b>', h1_style, 0),
    Paragraph(
        'After importing your repository, Vercel will show you a configuration page. This page lets you customize '
        'how your application is built and deployed. For most Next.js applications, Vercel auto-detects everything '
        'correctly, but we need to verify a few settings and add your environment variables.',
        body_style),

    add_heading('<b>5.1 Project Settings</b>', h2_style, 1),
    Paragraph(
        'On the "Configure Project" page, you will see several fields. Here is exactly what to set for each one. '
        'Vercel usually auto-detects these values, but double-check to make sure they are correct:',
        body_style),
    Spacer(1, 8),
])

settings_data = [
    [Paragraph('<b>Setting</b>', header_cell),
     Paragraph('<b>Value</b>', header_cell),
     Paragraph('<b>Notes</b>', header_cell)],
    [Paragraph('Project Name', cell_style),
     Paragraph('stayeg', cell_style),
     Paragraph('Auto-detected from repo name', cell_style)],
    [Paragraph('Framework Preset', cell_style),
     Paragraph('Next.js', cell_style),
     Paragraph('Auto-detected - do not change', cell_style)],
    [Paragraph('Root Directory', cell_style),
     Paragraph('.', cell_style),
     Paragraph('Default - leave as is (dot means root folder)', cell_style)],
    [Paragraph('Build Command', cell_style),
     Paragraph('next build', cell_style),
     Paragraph('Vercel sets this automatically for Next.js', cell_style)],
    [Paragraph('Output Directory', cell_style),
     Paragraph('.next', cell_style),
     Paragraph('Auto-detected - leave as is', cell_style)],
    [Paragraph('Install Command', cell_style),
     Paragraph('npm install', cell_style),
     Paragraph('Auto-detected - leave as is', cell_style)],
]

settings_table = Table(settings_data, colWidths=[AVAIL_W*0.25, AVAIL_W*0.25, AVAIL_W*0.50], hAlign='CENTER')
settings_table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEADER),
    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
    *[('BACKGROUND', (0, i), (-1, i), TABLE_STRIPE if i % 2 == 0 else colors.white) for i in range(1, 7)],
    ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ('LEFTPADDING', (0, 0), (-1, -1), 8),
    ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ('TOPPADDING', (0, 0), (-1, -1), 6),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
]))
story.append(settings_table)

story.extend([
    Spacer(1, 12),
    add_heading('<b>5.2 Add Environment Variables</b>', h2_style, 1),
    Paragraph(
        'This is the most important step. Environment variables are secret values that your application needs to '
        'connect to Supabase. Without these, your app will load but will not be able to fetch or save any data. '
        'Think of environment variables as passwords that your app uses to talk to the database.',
        body_style),
    Paragraph(
        'Scroll down on the configuration page until you see the <b>"Environment Variables"</b> section. '
        'You need to add exactly two variables. For each variable, fill in the Name, Value, and make sure the '
        'Environment is set to "Production, Preview, Development" (all three).',
        body_style),
    Spacer(1, 8),
])

env_data = [
    [Paragraph('<b>Variable Name</b>', header_cell),
     Paragraph('<b>Example Value</b>', header_cell),
     Paragraph('<b>Where to Find It</b>', header_cell)],
    [Paragraph('NEXT_PUBLIC_SUPABASE_URL', cell_style),
     Paragraph('https://abc123.supabase.co', cell_style),
     Paragraph('Supabase Dashboard -> Settings -> API -> Project URL', cell_style)],
    [Paragraph('NEXT_PUBLIC_SUPABASE_ANON_KEY', cell_style),
     Paragraph('eyJhbGciOiJIUzI1NiIs...(long string)', cell_style),
     Paragraph('Supabase Dashboard -> Settings -> API -> Project API keys', cell_style)],
]

env_table = Table(env_data, colWidths=[AVAIL_W*0.28, AVAIL_W*0.32, AVAIL_W*0.40], hAlign='CENTER')
env_table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEADER),
    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
    ('BACKGROUND', (0, 1), (-1, 1), colors.white),
    ('BACKGROUND', (0, 2), (-1, 2), TABLE_STRIPE),
    ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ('LEFTPADDING', (0, 0), (-1, -1), 8),
    ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ('TOPPADDING', (0, 0), (-1, -1), 6),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
]))
story.append(env_table)

story.append(Spacer(1, 10))
story.append(Paragraph(
    '<b>Important:</b> Copy these values exactly as they appear. Do not add quotes around the values. '
    'Do not add extra spaces before or after the values. The variable names must be typed exactly as shown, '
    'especially the NEXT_PUBLIC_ prefix which is required for Next.js to expose them to the browser.',
    note_style))

story.extend([
    Spacer(1, 12),
    add_heading('<b>5.3 Deploy!</b>', h2_style, 1),
    Paragraph(
        'Once you have verified the project settings and added both environment variables, you are ready to deploy. '
        'Click the blue <b>"Deploy"</b> button at the bottom of the page. Vercel will now:',
        body_style),
    Paragraph('1. Copy your code from GitHub to its servers', bullet_style, bulletText='-'),
    Paragraph('2. Install all required packages (npm install)', bullet_style, bulletText='-'),
    Paragraph('3. Build your Next.js application (next build)', bullet_style, bulletText='-'),
    Paragraph('4. Deploy the built application to its global CDN', bullet_style, bulletText='-'),
    Paragraph(
        'This process typically takes 2 to 4 minutes. You will see a progress screen with real-time logs showing '
        'each step. Do not close this page. Wait until you see the "Congratulations!" message with confetti animation. '
        'If the build fails, do not worry - scroll down to the Troubleshooting section (Section 7) for solutions.',
        body_style),
    Paragraph(
        'After a successful deployment, Vercel will give you a URL like: <b>https://stayeg-xxx.vercel.app</b>. '
        'Click this link or copy it to your browser to see your live application!',
        body_style),
])

# ═══════════════════════════════════════════════════════════
# SECTION 6: Post-Deployment Verification
# ═══════════════════════════════════════════════════════════
story.extend([
    Spacer(1, 18),
    add_heading('<b>6. Post-Deployment Verification</b>', h1_style, 0),
    Paragraph(
        'After your deployment is live, it is important to verify that everything works correctly. Open your live '
        'URL (for example, https://stayeg-xxx.vercel.app) in your browser and go through the following checks. '
        'Each check ensures a critical part of your application is functioning as expected.',
        body_style),

    add_heading('<b>6.1 Visual Check</b>', h2_style, 1),
    Paragraph(
        'First, verify that the page loads completely without any blank sections or missing content. The StayEg '
        'homepage should display the hero section, navigation menu, PG listings, and all interactive elements. '
        'Previously, there was an issue where content appeared blank due to animation settings. This has been fixed '
        'in the current codebase - all content sections are now visible immediately when the page loads, even before '
        'JavaScript finishes loading. If you see any blank sections, check the troubleshooting section below.',
        body_style),

    add_heading('<b>6.2 Data Fetching Check</b>', h2_style, 1),
    Paragraph(
        'Verify that your application can fetch data from Supabase. Look for PG listings, user data, or any content '
        'that comes from the database. If the pages load but show no data (empty listings, no user info), this '
        'typically means the environment variables are not set correctly. Double-check that both NEXT_PUBLIC_SUPABASE_URL '
        'and NEXT_PUBLIC_SUPABASE_ANON_KEY are entered exactly as shown in Section 5.2, with no extra spaces or quotes.',
        body_style),

    add_heading('<b>6.3 Interactivity Check</b>', h2_style, 1),
    Paragraph(
        'Test the interactive features of your application: click on navigation links, try the search functionality, '
        'open modals and dialogs, submit forms if applicable. Make sure all buttons respond to clicks and all dropdown '
        'menus open correctly. If some interactions do not work, it may indicate a JavaScript error. Open the browser '
        'developer console (press F12, then click the Console tab) to check for any red error messages.',
        body_style),

    add_heading('<b>6.4 Mobile Responsiveness Check</b>', h2_style, 1),
    Paragraph(
        'Resize your browser window to simulate different screen sizes (or use your phone to visit the URL). '
        'The StayEg application uses Tailwind CSS with responsive design, so it should adapt seamlessly to mobile, '
        'tablet, and desktop screen sizes. Check that the navigation menu collapses properly on small screens, '
        'that content does not overflow horizontally, and that all interactive elements remain tappable on touch devices.',
        body_style),
])

# ═══════════════════════════════════════════════════════════
# SECTION 7: Troubleshooting
# ═══════════════════════════════════════════════════════════
story.extend([
    Spacer(1, 18),
    add_heading('<b>7. Troubleshooting Common Issues</b>', h1_style, 0),
    Paragraph(
        'If something goes wrong during or after deployment, do not panic. Most issues are easy to fix. Below are the '
        'most common problems and their solutions, ordered by how frequently they occur.',
        body_style),
])

add_heading('<b>7.1 Build Failed on Vercel</b>', h2_style, 1),
story.append(Paragraph(
    'If Vercel shows a "Build Failed" error, scroll down in the deployment logs to find the specific error message. '
    'The most common causes and their fixes are:',
    body_style))
story.append(code_block(
    '# Error: "Could not resolve dependency"\n'
    '# Fix: Make sure all files are pushed to GitHub\n'
    'git add . && git commit -m "Fix: add missing files" && git push\n\n'
    '# Error: "TypeScript compilation error"\n'
    '# Fix: The project has ignoreBuildErrors: true in next.config.ts\n'
    '# If you still get errors, check the specific file mentioned in the log\n\n'
    '# Error: "Build command failed with exit code 1"\n'
    '# Fix: Check the full log. Usually a missing package or syntax error.'
))

story.extend([
    add_heading('<b>7.2 Page Loads But Shows No Data</b>', h2_style, 1),
    Paragraph(
        'If your website loads visually but all data sections are empty (no PG listings, no user data, no bookings), '
        'the issue is almost certainly with your Supabase environment variables. Go to your Vercel project dashboard, '
        'click on Settings then Environment Variables, and verify that:',
        body_style),
    Paragraph('1. <b>NEXT_PUBLIC_SUPABASE_URL</b> starts with "https://" and ends with ".supabase.co"', bullet_style, bulletText='-'),
    Paragraph('2. <b>NEXT_PUBLIC_SUPABASE_ANON_KEY</b> is a long string starting with "eyJ..."', bullet_style, bulletText='-'),
    Paragraph('3. Both variables have the environment checkboxes for Production, Preview, and Development all selected', bullet_style, bulletText='-'),
    Paragraph('4. There are no leading or trailing spaces in either value', bullet_style, bulletText='-'),
    Paragraph(
        'After fixing the variables, go to the Deployments tab in Vercel and click the three dots next to your latest '
        'deployment, then click "Redeploy". This will rebuild your app with the corrected environment variables.',
        body_style),
])

add_heading('<b>7.3 Page Appears Blank or White</b>', h2_style, 1)
story.append(Paragraph(
    'If the page loads but appears completely blank or shows a white screen, this was the opacity animation issue '
    'that has been fixed in the current version of your code. If you still see this issue, make sure the latest code '
    'changes have been pushed to GitHub. The fix involved changing all animation initial states from opacity: 0 to '
    'opacity: 1 so content is visible immediately. If the issue persists after confirming the latest code is deployed, '
    'try hard-refreshing your browser (Ctrl+Shift+R on Windows, Cmd+Shift+R on Mac) to clear cached JavaScript files.',
    body_style))

story.extend([
    add_heading('<b>7.4 404 Error or "Page Not Found"</b>', h2_style, 1),
    Paragraph(
        'If you see a 404 error, first check that you are visiting the correct URL. Go to your Vercel dashboard, '
        'click on your project, and copy the exact domain shown there. Also make sure you have a page.tsx file in the '
        'src/app/ directory of your project. The Next.js App Router requires a page.tsx file in the app directory to '
        'serve the root route ("/"). If you accidentally deleted or renamed this file, restore it from your Git history.',
        body_style),
])

add_heading('<b>7.5 How to Update After Deployment</b>', h2_style, 1)
story.extend([
    Paragraph(
        'One of the best things about Vercel is automatic deployments. Any time you push code changes to GitHub, '
        'Vercel automatically detects the change and redeploys your application. You do not need to do anything on '
        'Vercel after the initial setup. The workflow is simple:',
        body_style),
    code_block(
        '# 1. Make changes to your code locally\n'
        '# 2. Add and commit the changes\n'
        'git add .\n'
        'git commit -m "Update: description of your changes"\n\n'
        '# 3. Push to GitHub\n'
        'git push\n\n'
        '# 4. Vercel automatically detects and redeploys!\n'
        '# Check your Vercel dashboard for the deployment status.'
    ),
    Paragraph(
        'Each deployment creates a unique preview URL, so you can test changes before they go live to your main URL. '
        'Vercel also keeps a history of all deployments, so you can roll back to any previous version with one click '
        'if something goes wrong.',
        body_style),
])

# ═══════════════════════════════════════════════════════════
# SECTION 8: Custom Domain (Optional)
# ═══════════════════════════════════════════════════════════
story.extend([
    Spacer(1, 18),
    add_heading('<b>8. Custom Domain (Optional)</b>', h1_style, 0),
    Paragraph(
        'By default, Vercel gives you a free subdomain like stayeg-xxx.vercel.app. If you have purchased your own '
        'domain name (for example, stayeg.com), you can connect it to your Vercel deployment. This makes your '
        'application look more professional and is easier for users to remember.',
        body_style),
    Paragraph('1. Go to your Vercel project dashboard', bullet_style, bulletText='-'),
    Paragraph('2. Click on <b>Settings</b> then <b>Domains</b>', bullet_style, bulletText='-'),
    Paragraph('3. Type your domain name (e.g., stayeg.com) and click <b>Add</b>', bullet_style, bulletText='-'),
    Paragraph('4. Vercel will show you DNS records to add at your domain registrar', bullet_style, bulletText='-'),
    Paragraph('5. Go to your domain registrar (GoDaddy, Namecheap, etc.) and add the DNS records', bullet_style, bulletText='-'),
    Paragraph('6. Wait for DNS propagation (can take a few minutes to a few hours)', bullet_style, bulletText='-'),
    Paragraph(
        'Vercel also automatically provisions an SSL certificate for your custom domain, so your website will be '
        'accessible via HTTPS (secure connection) at no extra cost. The entire process usually completes within an hour.',
        body_style),
])

# ═══════════════════════════════════════════════════════════
# SECTION 9: Quick Reference
# ═══════════════════════════════════════════════════════════
story.extend([
    Spacer(1, 18),
    add_heading('<b>9. Quick Reference</b>', h1_style, 0),
    Paragraph(
        'Use this section as a quick reminder of key URLs, commands, and settings for your StayEg deployment.',
        body_style),
    Spacer(1, 8),
])

ref_data = [
    [Paragraph('<b>Resource</b>', header_cell),
     Paragraph('<b>URL / Command</b>', header_cell)],
    [Paragraph('Vercel Dashboard', cell_style),
     Paragraph('https://vercel.com/dashboard', cell_style)],
    [Paragraph('GitHub Repository', cell_style),
     Paragraph('https://github.com/YOUR_USERNAME/stayeg', cell_style)],
    [Paragraph('Supabase Dashboard', cell_style),
     Paragraph('https://supabase.com/dashboard', cell_style)],
    [Paragraph('Push new changes', cell_style),
     Paragraph('git add . && git commit -m "update" && git push', cell_style)],
    [Paragraph('View build logs', cell_style),
     Paragraph('Vercel Dashboard -> Project -> Deployments -> Click deploy', cell_style)],
    [Paragraph('Add env variables', cell_style),
     Paragraph('Vercel Dashboard -> Project -> Settings -> Environment Variables', cell_style)],
    [Paragraph('Redeploy', cell_style),
     Paragraph('Vercel Dashboard -> Deployments -> Three dots -> Redeploy', cell_style)],
]

ref_table = Table(ref_data, colWidths=[AVAIL_W*0.30, AVAIL_W*0.70], hAlign='CENTER')
ref_table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEADER),
    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
    *[('BACKGROUND', (0, i), (-1, i), TABLE_STRIPE if i % 2 == 0 else colors.white) for i in range(1, 8)],
    ('GRID', (0, 0), (-1, -1), 0.5, BORDER_COLOR),
    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ('LEFTPADDING', (0, 0), (-1, -1), 8),
    ('RIGHTPADDING', (0, 0), (-1, -1), 8),
    ('TOPPADDING', (0, 0), (-1, -1), 6),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
]))
story.append(ref_table)

# ── Build ──
doc.multiBuild(story)
print(f'PDF generated: {output_path}')
